package app;

public class Main {
    public static void main(String[] args) {
        LatentSpaceExplorer.main(args);
    }
}